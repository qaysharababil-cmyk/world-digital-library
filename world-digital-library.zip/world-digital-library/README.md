# World Digital Library

A responsive multi-source book discovery website built with HTML, CSS, and vanilla JavaScript.

## Features
- Search Open Library, Google Books, Project Gutenberg, and Internet Archive.
- Unified book cards with source, author, year, and cover where available.
- Book detail modal with source link and availability note.
- Save/bookmark books using browser LocalStorage.
- Filter by source and sort by title or publication year.
- Responsive layout for desktop and mobile.

## Run locally
1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. Recommended: install the **Live Server** extension.
4. Right-click `index.html` → **Open with Live Server**.
5. Search for a title, author, or topic.

You can also open `index.html` directly in a browser, but a local development server is recommended.

## Data sources
- Open Library Search API: https://openlibrary.org/developers/api
- Google Books API: https://developers.google.com/books
- Gutendex (Project Gutenberg catalogue): https://gutendex.com/
- Internet Archive Advanced Search: https://archive.org/advancedsearch.php

## Important limitations
- This is a discovery/catalogue interface, not a copy of every book in the world.
- Results depend on each provider's API, network availability, rate limits, and coverage.
- Reading previews, full text, lending, and downloads are controlled by the original provider and rights holder.
- The app only links to source pages or previews exposed by providers; it does not bypass paywalls, borrowing controls, or copyright restrictions.
- Saved books are stored in the current browser on the current device. There is no user account or cloud sync in this starter version.
- Some APIs may have browser CORS, quota, or availability restrictions. If a source fails, the app reports the source as unavailable and continues with other sources.

## Suggested next development phase
1. Add a backend API proxy and caching layer.
2. Add authentication and cloud-synced reading lists.
3. Add richer ISBN and edition matching to merge duplicate records.
4. Add language, publication year, and access-type filters.
5. Add a proper admin dashboard and database.
