const API = {
  openLibrary: "https://openlibrary.org/search.json",
  googleBooks: "https://www.googleapis.com/books/v1/volumes",
  gutenberg: "https://gutendex.com/books/",
  archive: "https://archive.org/advancedsearch.php"
};

const state = { query: "", page: 1, allBooks: [], visibleBooks: [], saved: loadSaved(), savedOnly: false, activeBook: null, loading: false };
const $ = (id) => document.getElementById(id);
const grid = $("bookGrid");

function loadSaved(){ try{return JSON.parse(localStorage.getItem("worldLibrarySaved") || "[]")}catch{return []} }
function saveSaved(){ localStorage.setItem("worldLibrarySaved", JSON.stringify(state.saved)); updateSavedCount(); }
function updateSavedCount(){ $("savedCount").textContent = state.saved.length; }
function escapeHTML(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function normalizeBook(book){return {...book, id:String(book.id || `${book.source}-${book.title}-${book.author}`), title:book.title || "Untitled", author:book.author || "Unknown author", year:book.year || "", cover:book.cover || "", description:book.description || "No description is available from this source.", source:book.source || "Unknown", url:book.url || "#"};}
function coverFor(title){return `https://placehold.co/360x500/e8e5dc/35445a?text=${encodeURIComponent(title.slice(0,28))}`;}
function isSaved(book){return state.saved.some(item=>item.id===book.id);}
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2200);}

async function searchOpenLibrary(q, page){
  const url=`${API.openLibrary}?q=${encodeURIComponent(q)}&page=${page}&limit=20&fields=key,title,author_name,first_publish_year,cover_i,edition_count,subject`;
  const res=await fetch(url); if(!res.ok) throw new Error("Open Library unavailable");
  const data=await res.json();
  return (data.docs||[]).map(x=>normalizeBook({id:`ol-${x.key}`,title:x.title,author:(x.author_name||[]).slice(0,3).join(", "),year:x.first_publish_year,cover:x.cover_i?`https://covers.openlibrary.org/b/id/${x.cover_i}-M.jpg`:"",description:x.subject?.slice(0,5).join(" · ")||"",source:"Open Library",url:`https://openlibrary.org${x.key}`,meta:`${x.edition_count||"—"} editions`}));
}
async function searchGoogle(q){
  const url=`${API.googleBooks}?q=${encodeURIComponent(q)}&maxResults=20&printType=books&orderBy=relevance`;
  const res=await fetch(url); if(!res.ok) throw new Error("Google Books unavailable");
  const data=await res.json();
  return (data.items||[]).map(x=>{const v=x.volumeInfo||{};return normalizeBook({id:`gb-${x.id}`,title:v.title,author:(v.authors||[]).join(", "),year:v.publishedDate?.slice(0,4),cover:v.imageLinks?.thumbnail?.replace("http:","https:")||"",description:v.description||"",source:"Google Books",url:v.previewLink||v.infoLink||`https://books.google.com/books?id=${x.id}`,meta:v.publisher||""})});
}
async function searchGutenberg(q, page){
  const url=`${API.gutenberg}?search=${encodeURIComponent(q)}&page=${page}`;
  const res=await fetch(url); if(!res.ok) throw new Error("Project Gutenberg unavailable");
  const data=await res.json();
  return (data.results||[]).map(x=>normalizeBook({id:`pg-${x.id}`,title:x.title,author:(x.authors||[]).map(a=>a.name).join(", "),year:x.copyright?"Copyrighted":"Public domain status varies by country",cover:x.formats?.["image/jpeg"]||"",description:"A digital book in the Project Gutenberg collection. Check the source for formats and regional rights.",source:"Project Gutenberg",url:x.formats?.["text/html"]||x.formats?.["text/plain; charset=utf-8"]||`https://www.gutenberg.org/ebooks/${x.id}`,meta:"eBook"}));
}
async function searchArchive(q, page){
  const params=new URLSearchParams({q:`(${q}) AND mediatype:texts`,"fl[]":"identifier,title,creator,year,description",rows:"20",page:String(page),output:"json"});
  const res=await fetch(`${API.archive}?${params.toString()}`); if(!res.ok) throw new Error("Internet Archive unavailable");
  const data=await res.json();
  return (data.response?.docs||[]).map(x=>normalizeBook({id:`ia-${x.identifier}`,title:x.title,author:Array.isArray(x.creator)?x.creator.join(", "):x.creator,year:x.year,cover:`https://archive.org/services/img/${x.identifier}`,description:Array.isArray(x.description)?x.description.join(" "):x.description,source:"Internet Archive",url:`https://archive.org/details/${x.identifier}`,meta:"Archive item"}));
}

async function runSearch(q, page=1){
  state.query=q;state.page=page;state.savedOnly=false;state.loading=true;
  $("resultsTitle").textContent=`Results for “${q}”`;
  $("resultsSubtitle").textContent="Searching connected digital collections. Availability varies by source.";
  $("statusLine").innerHTML='<span class="loader"></span> Searching across four digital collections...';
  $("emptyState").classList.add("hidden");$("loadMore").classList.add("hidden");
  if(page===1){state.allBooks=[];renderBooks([]);}
  const jobs=await Promise.allSettled([searchOpenLibrary(q,page),searchGoogle(q),searchGutenberg(q,page),searchArchive(q,page)]);
  const names=["Open Library","Google Books","Project Gutenberg","Internet Archive"];
  let added=0,failed=[];
  jobs.forEach((job,i)=>{if(job.status==="fulfilled"){state.allBooks.push(...job.value);added+=job.value.length}else failed.push(names[i]);});
  state.loading=false;
  state.allBooks=dedupe(state.allBooks);
  applyFilters();
  const sourceCount=4-failed.length;
  $("statusLine").textContent=`${state.allBooks.length} results found · ${sourceCount}/4 sources connected${failed.length?` · Unavailable: ${failed.join(", ")}`:""}`;
  if(!state.allBooks.length){$("emptyState").classList.remove("hidden");$("statusLine").textContent=failed.length===4?"All sources are temporarily unavailable. Check your connection and try again.":"No matching books found.";}
  $("loadMore").classList.toggle("hidden",!q || added===0 || page>1);
}
function dedupe(books){const seen=new Set();return books.filter(b=>{const k=(b.title+"|"+b.author).toLowerCase().replace(/[^a-z0-9]+/g,"");if(seen.has(k))return false;seen.add(k);return true;});}
function applyFilters(){
  const source=$("sourceFilter").value,sort=$("sortFilter").value;
  let books=state.savedOnly?state.saved.slice():state.allBooks.slice();
  if(source!=="all")books=books.filter(b=>b.source===source);
  if(sort==="title")books.sort((a,b)=>a.title.localeCompare(b.title));
  if(sort==="year")books.sort((a,b)=>(parseInt(b.year)||0)-(parseInt(a.year)||0));
  state.visibleBooks=books;renderBooks(books);
}
function renderBooks(books){
  grid.innerHTML=books.map(book=>`<article class="book-card" data-id="${escapeHTML(book.id)}" tabindex="0" role="button" aria-label="View ${escapeHTML(book.title)}">
    <div class="cover-wrap"><img loading="lazy" src="${escapeHTML(book.cover||coverFor(book.title))}" alt="Cover of ${escapeHTML(book.title)}" onerror="this.onerror=null;this.src='${coverFor(book.title)}'">
    <button class="save-icon ${isSaved(book)?"saved":""}" data-save="${escapeHTML(book.id)}" aria-label="${isSaved(book)?"Remove saved book":"Save book"}">${isSaved(book)?"♥":"♡"}</button></div>
    <span class="book-source">${escapeHTML(book.source)}</span><h3>${escapeHTML(book.title)}</h3><p class="book-author">${escapeHTML(book.author)}</p><div class="book-year">${escapeHTML(book.year||"Publication year unknown")}</div>
  </article>`).join("");
  $("emptyState").classList.toggle("hidden",books.length>0);
}
function openBook(book){
  state.activeBook=book;
  $("modalCover").src=book.cover||coverFor(book.title);
  $("modalCover").onerror=()=>{$("modalCover").src=coverFor(book.title)};
  $("modalSource").textContent=book.source;
  $("modalTitle").textContent=book.title;
  $("modalAuthor").textContent=book.author;
  $("modalMeta").textContent=[book.year,book.meta].filter(Boolean).join(" · ")||"Publication details unavailable";
  $("modalDescription").textContent=book.description||"The source does not provide a description for this book.";
  $("modalOpen").href=book.url;
  $("modalSave").textContent=isSaved(book)?"♥ Saved — remove":"♡ Save to collection";
  $("bookModal").classList.remove("hidden");
}
function toggleSave(book){
  if(isSaved(book)){state.saved=state.saved.filter(x=>x.id!==book.id);toast("Removed from your saved collection.");}
  else{state.saved.unshift(book);toast("Book saved to your collection.");}
  saveSaved();
  if(state.savedOnly)applyFilters();else renderBooks(state.visibleBooks);
  if(state.activeBook?.id===book.id)$("modalSave").textContent=isSaved(book)?"♥ Saved — remove":"♡ Save to collection";
}

$("searchForm").addEventListener("submit",e=>{e.preventDefault();const q=$("searchInput").value.trim();if(q)runSearch(q);});
document.querySelectorAll("[data-query]").forEach(btn=>btn.addEventListener("click",()=>{$("searchInput").value=btn.dataset.query;runSearch(btn.dataset.query);}));
grid.addEventListener("click",e=>{
  const saveBtn=e.target.closest("[data-save]");
  if(saveBtn){e.stopPropagation();const book=state.visibleBooks.find(b=>b.id===saveBtn.dataset.save)||state.allBooks.find(b=>b.id===saveBtn.dataset.save)||state.saved.find(b=>b.id===saveBtn.dataset.save);if(book)toggleSave(book);return;}
  const card=e.target.closest(".book-card");if(card){const book=state.visibleBooks.find(b=>b.id===card.dataset.id);if(book)openBook(book);}
});
grid.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.classList.contains("book-card")){e.preventDefault();const b=state.visibleBooks.find(x=>x.id===e.target.dataset.id);if(b)openBook(b);}});
$("sourceFilter").addEventListener("change",applyFilters);$("sortFilter").addEventListener("change",applyFilters);
$("savedToggle").addEventListener("click",()=>{
  state.savedOnly=!state.savedOnly;
  $("resultsTitle").textContent=state.savedOnly?"Your saved books":"Explore the library";
  $("resultsSubtitle").textContent=state.savedOnly?"Your personal reading collection, saved on this device.":"Search across multiple collections to find your next read.";
  $("statusLine").textContent=state.savedOnly?`${state.saved.length} saved books`:"";
  applyFilters();
});
$("modalClose").addEventListener("click",()=>$("bookModal").classList.add("hidden"));
$("bookModal").addEventListener("click",e=>{if(e.target===$("bookModal"))$("bookModal").classList.add("hidden")});
document.addEventListener("keydown",e=>{if(e.key==="Escape")$("bookModal").classList.add("hidden")});
$("modalSave").addEventListener("click",()=>{if(state.activeBook)toggleSave(state.activeBook)});
$("loadMore").addEventListener("click",()=>{if(state.query&&!state.loading)runSearch(state.query,state.page+1)});
$("year").textContent=new Date().getFullYear();updateSavedCount();
$("statusLine").textContent="Ready when you are — search for a book, author, or subject.";
